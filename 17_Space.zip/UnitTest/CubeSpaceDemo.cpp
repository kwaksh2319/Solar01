#include "stdafx.h"
#include "CubeSpaceDemo.h"

void CubeSpaceDemo::Initialize()
{
	Context::Get()->GetCamera()->RotationDegree(20, 0, 0);
	Context::Get()->GetCamera()->Position(1, 36, -85);


	shader = new Shader(L"15_Mesh.fx");

	shaderSolar=new Shader(L"15_MeshSolar.fx");

	//sky = new CubeSky(L"Environment/GrassCube1024.dds");
	sky = new CubeSky(L"Environment/Starfield.dds");	
	sDirection = shader->AsVector("Direction");
	sDirectionSolar = shaderSolar->AsVector("Directions");
	sRad = shaderSolar->AsVector("Radius");
	CreateMesh();


	cubeMapShader = new Shader(L"16_CubeMap.fx");
	cubeMap = new CubeMap(cubeMapShader);
	//cubeMap->Texture(L"Environment/SunsetCube1024.dds");
	cubeMap->Texture(L"Environment/Earth.dds");
	cubeMap->GetTransform()->Position(0, 20, 0);
	cubeMap->GetTransform()->Scale(10, 10, 10);
	mercury->GetTransform()->Position(&point);
	
	
}

void CubeSpaceDemo::Destroy()
{
	SafeDelete(shader);
	SafeDelete(shaderSolar);
	SafeDelete(sky);
	/*
	SafeDelete(cube);
	SafeDelete(grid);

	for (UINT i = 0; i < 10; i++)
	{
		SafeDelete(cylinder[i]);
		SafeDelete(sphere[i]);
	}
	*/
	SafeDelete(mercury);
	SafeDelete(tmp);
	SafeDelete(sun);
	SafeDelete(cubeMapShader);
	SafeDelete(cubeMap);
}

void CubeSpaceDemo::Update()
{
	sky->Update();
	sun->Update();
	mercury->Update();
	tmp->Update();
	/*
	cube->Update();
	grid->Update();

	for (int i = 0; i < 10; i++)
	{
		cylinder[i]->Update();
		sphere[i]->Update();
	}*/
	

	//float timer = 60*Time::Delta();
	//point.x += 30 * Time::Delta();
	Vector3 pos;
	sun->GetTransform()->Position(&pos);



	radius1.x = 3.0f;
	radius1.y = 3.0f;
	radius2.x = 5.0f;
	radius2.y = 5.0f;
	static float alpa=0.0f;
	
	//if (Keyboard::Get()->Press(VK_UP)) {
	alpa = alpa + 1 * Time::Delta();
	
	 point.x +=  10.0f * cosf(alpa)*Time::Delta();
     point.z +=  10.0f * sinf(alpa)* Time::Delta();

	//}
	
	mercury->GetTransform()->Position(point);
	//Vector3 point;
	//point.z += sin(timer) * 3.0f;
	//MercuryPositionUpdate(point);
	
	
	cubeMap->GetTransform()->Position(pos);

	tmp->GetTransform()->Position(point.x+10, point.y , point.z + 10);

	cubeMap->Update();
}

void CubeSpaceDemo::Render()
{
	sky->Render();
	
	ImGui::SliderFloat3("Direction", direction, -1, +1);
	ImGui::SliderFloat3("point", point, -10000, +10000);
	sDirection->SetFloatVector(direction);
	sDirectionSolar->SetFloatVector(direction);
	sRad->SetFloatVector(radius1);
	
	//cube->Pass(1);
	//cube->Render();

	//grid->Pass(1);
	//grid->Render();


	static int pass = 0;
	ImGui::InputInt("Pass", &pass);
	pass %= 2;

	for (int i = 0; i < 10; i++)
	{
		//cylinder[i]->Pass(pass);
		//cylinder[i]->Render();

		//sphere[i]->Pass(pass);
		//sphere[i]->Render();
	}
	sun->Render();
	mercury->Render();
	tmp->Render();
	cubeMap->Render();
}

void CubeSpaceDemo::CreateMesh()
{
	sun = new MeshSphere(shader,0.5f,20,20 );
	sun->GetTransform()->Position(30, 15.5f,-15.0f);
	sun->GetTransform()->Scale(20, 20, 20);
	sun->DiffuseMap(L"SunSolar.png");

	mercury= new MeshSphere(shaderSolar, 0.5f, 20, 20);
	mercury->GetTransform()->Position(70, 15.5f, -15.0f);
	mercury->GetTransform()->Scale(5, 5, 5);
	mercury->DiffuseMap(L"MercurySolar.png");

	tmp = new MeshSphere(shaderSolar, 0.5f, 20, 20);
	tmp->GetTransform()->Position(30, 15.5f, -15.0f);
	tmp->GetTransform()->Scale(5, 5, 5);
	tmp->DiffuseMap(L"MercurySolar.png");
	/*
		grid = new MeshGrid(shader, 6, 6);
		grid->GetTransform()->Scale(12, 1, 12);
		grid->DiffuseMap(L"Floor.png");


		for (UINT i = 0; i < 5; i++)
		{
			cylinder[i * 2] = new MeshCylinder(shader, 0.30f, 0.5f, 3.0f, 20, 20);
			cylinder[i * 2]->GetTransform()->Position(-30, 6, (float)i * 15.0f - 15.0f);
			cylinder[i * 2]->GetTransform()->Scale(5, 5, 5);
			cylinder[i * 2]->DiffuseMap(L"Bricks.png");

			cylinder[i * 2 + 1] = new MeshCylinder(shader, 0.30f, 0.5f, 3.0f, 20, 20);
			cylinder[i * 2 + 1]->GetTransform()->Position(30, 6, (float)i * 15.0f - 15.0f);
			cylinder[i * 2 + 1]->GetTransform()->Scale(5, 5, 5);
			cylinder[i * 2 + 1]->DiffuseMap(L"Bricks.png");


			sphere[i * 2] = new MeshSphere(shader, 0.5f, 20, 20);
			sphere[i * 2]->GetTransform()->Position(-30, 15.5f, (float)i * 15.0f - 15.0f);
			sphere[i * 2]->GetTransform()->Scale(5, 5, 5);
			sphere[i * 2]->DiffuseMap(L"Wall.png");

			sphere[i * 2 + 1] = new MeshSphere(shader, 0.5f, 20, 20);
			sphere[i * 2 + 1]->GetTransform()->Position(30, 15.5f, (float)i * 15.0f - 15.0f);
			sphere[i * 2 + 1]->GetTransform()->Scale(5, 5, 5);
			sphere[i * 2 + 1]->DiffuseMap(L"Wall.png");




		}*/
}

void CubeSpaceDemo::MercuryPositionUpdate(Vector3 point)
{


	
	

	
}
